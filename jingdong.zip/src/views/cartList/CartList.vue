<template>
    <div>
        cartList
    </div>
</template>

<script>
export default {
name:'CartList'
}
</script>

<style lang="scss" scoped>
</style>